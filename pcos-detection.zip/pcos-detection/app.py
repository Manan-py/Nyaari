from flask import Flask, request, jsonify
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import os

app = Flask(__name__)

# Load the PCOS detection model with the correct path
model_path = r"C:\Users\Mrityunjai\Downloads\pcos-detection\pcos-detection\components\vgg16_pcos_detection_final.h5"
model = load_model(model_path)

# Function to preprocess the input image
def preprocess_image(img_path):
    img = image.load_img(img_path, target_size=(224, 224))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array = img_array / 255.0  # Normalize to [0, 1]
    return img_array

# Endpoint for PCOS detection
@app.route('/upload', methods=['POST'])
def predict_pcos():
    if 'image' not in request.files:
        return jsonify({'error': 'No image file in the request'}), 400

    file = request.files['image']

    if file.filename == '':
        return jsonify({'error': 'No file selected for uploading'}), 400

    if file:
        file_path = os.path.join('uploads', file.filename)
        file.save(file_path)

        img = preprocess_image(file_path)
        prediction = model.predict(img)

        prediction_class = 'Positive' if prediction[0][0] > 0.5 else 'Negative'

        os.remove(file_path)

        return jsonify({'pcos': prediction_class})

if __name__ == '__main__':
    if not os.path.exists('uploads'):
        os.makedirs('uploads')
    app.run(debug=True)

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './ImageUpload.css'; // Import the CSS file

const ImageUpload = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const navigate = useNavigate();

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setSelectedImage(file);

    // Generate a preview of the image
    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result);
    };
    if (file) {
      reader.readAsDataURL(file);
    } else {
      setImagePreview(null);
    }
  };

  const handleUpload = async () => {
    if (!selectedImage) return;
  
    const formData = new FormData();
    formData.append('image', selectedImage);  // The key 'image' must match what the backend expects
  
    try {
      const response = await axios.post('http://127.0.0.1:5000/upload', formData);  // Correct backend URL
      const result = response.data;
      navigate('/result', { state: { result } });
    } catch (error) {
      console.error('Error uploading the image:', error);
    }
  };  

  return (
    <div className="upload-container">
      {/* First Section */}
      <div className="section title-section">
        <h1>PCOS Detection</h1>
        <p className="subtitle">Upload your ultrasound image for detection</p>
      </div>

      {/* Second Section */}
      <div className="section upload-section">
        <div className="file-container">
          <input type="file" onChange={handleImageChange} />
        </div>
        <div className="image-preview-container">
          <h2 className="image-preview-title">Image Preview</h2>
          {imagePreview && (
            <div className="image-container">
              <img src={imagePreview} alt="Selected Preview" />
            </div>
          )}
        </div>
      </div>

      {/* Third Section: Placeholder for footer */}
      <div className="section footer-section">
        {/* Footer content goes here */}
      </div>

      <button onClick={handleUpload} disabled={!selectedImage}>
        Upload
      </button>
    </div>
  );
};

export default ImageUpload;


